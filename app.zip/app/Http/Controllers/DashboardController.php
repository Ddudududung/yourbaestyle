<?php

namespace App\Http\Controllers;

use App\Models\Produk;
use App\Models\TransaksiPos;
use App\Models\PesananOnline;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $hariIni = Carbon::today();

        // 1. STATISTIK KARTU ATAS (Sesuaikan dengan yang sudah ada di controllermu)
        $transaksiHariIni = TransaksiPos::whereDate('tanggal', $hariIni)->count() 
                          + PesananOnline::whereDate('tanggal', $hariIni)->count();
                          
        $penjualanHariIni = TransaksiPos::whereDate('tanggal', $hariIni)->sum('total_harga') 
                          + PesananOnline::whereDate('tanggal', $hariIni)->sum('total_harga');

        $totalStok  = Produk::where('status', 'aktif')->sum('stok');
        $totalHabis = Produk::where('status', 'aktif')->where('stok', 0)->count();

        // 2. PRODUK STOK RENDAH (Untuk tabel bawah)
        $lowStockProducts = Produk::where('status', 'aktif')
                            ->where('stok', '<=', 5) // Batas stok minimum
                            ->orderBy('stok', 'asc')
                            ->take(5)
                            ->get();

        // =========================================================================
        // 3. INTI SOLUSI: GABUNGKAN TRANSAKSI POS & ONLINE UNTUK "TRANSAKSI TERAKHIR"
        // =========================================================================
        
        // A. Ambil 5 transaksi terbaru dari Kasir / POS
        $pos = TransaksiPos::with(['user', 'detail.produk'])
            ->orderBy('tanggal', 'desc')
            ->take(5)
            ->get()
            ->map(function ($item) {
                return (object) [
                    'no_transaksi' => $item->kode_transaksi ?? ($item->no_pesanan ?? '-'),
                    'produk_nama'  => $item->detail->first()->produk->nama_produk ?? 'Beragam Produk POS',
                    'qty'          => $item->detail->sum('qty') ?: 1,
                    'total'        => $item->total_harga,
                    'created_at'   => Carbon::parse($item->tanggal),
                    'user_name'    => $item->user->name ?? 'Kasir POS',
                ];
            });

        // B. Ambil 5 transaksi terbaru dari Pesanan Online (Shopee / TikTok)
        $online = PesananOnline::with(['user', 'detail.produk'])
            ->orderBy('tanggal', 'desc')
            ->take(5)
            ->get()
            ->map(function ($item) {
                // Ambil nama produk dari relasi, jika kosong ambil dari string variasi import
                $namaProduk = $item->detail->first()->produk->nama_produk 
                           ?? ($item->detail->first()->variasi ?? 'Pesanan Online');
                           
                return (object) [
                    'no_transaksi' => $item->no_pesanan,
                    'produk_nama'  => $namaProduk,
                    'qty'          => $item->detail->sum('qty') ?: 1,
                    'total'        => $item->total_harga,
                    'created_at'   => Carbon::parse($item->tanggal),
                    'user_name'    => strtoupper($item->platform ?? 'ONLINE'), // Menampilkan SHOPEE / TIKTOK
                ];
            });

        // C. Gabungkan keduanya, urutkan dari yang paling baru, dan ambil 6 teratas
        $recentTransactions = $pos->concat($online)
            ->sortByDesc('created_at')
            ->take(6)
            ->values();

        // 4. KIRIM SEMUA VARIABEL KE VIEW DASHBOARD
        return view('dashboard', compact(
            'transaksiHariIni',
            'penjualanHariIni',
            'totalStok',
            'totalHabis',
            'lowStockProducts',
            'recentTransactions' // <-- Pastikan ini terkirim!
        ));
    }
}