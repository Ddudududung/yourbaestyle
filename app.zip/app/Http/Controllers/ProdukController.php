<?php

namespace App\Http\Controllers;

use App\Models\Produk;
use App\Models\Pemasok;
use App\Models\PembelianBarang;
use App\Models\MsJenisPakaian;
use App\Models\MsWarna;
use App\Models\MsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class ProdukController extends Controller
{
    // ============================================================
    // INDEX — Daftar semua produk dengan filter Master Data
    // ============================================================
    public function index(Request $request)
    {
        // Gunakan Eager Loading untuk master data agar query cepat
        $query = Produk::with(['jenisPakaian', 'warna', 'model', 'pemasok']);

        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('nama_produk', 'like', '%' . $request->search . '%')
                  ->orWhere('kode_produk', 'like', '%' . $request->search . '%');
            });
        }

        // Filter berdasarkan Master Data baru
        if ($request->filled('id_jenis_pakaian')) {
            $query->where('id_jenis_pakaian', $request->id_jenis_pakaian);
        }
        if ($request->filled('id_warna')) {
            $query->where('id_warna', $request->id_warna);
        }
        if ($request->filled('id_model')) {
            $query->where('id_model', $request->id_model);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $produk = $query->orderBy('created_at', 'desc')->paginate(10)->withQueryString();
        
        // Ambil data master untuk pilihan dropdown filter di view index
        $jenisPakaian = MsJenisPakaian::orderBy('nama')->get();
        $warna = MsWarna::orderBy('nama')->get();
        $model = MsModel::orderBy('nama')->get();

        return view('produk.index', compact('produk', 'jenisPakaian', 'warna', 'model'));
    }

    // ============================================================
    // CREATE — Form tambah produk
    // ============================================================
    public function create()
    {
        $pemasok = Pemasok::orderBy('nama_pemasok')->get();
        $jenisPakaian = MsJenisPakaian::orderBy('nama')->get();
        $warna = MsWarna::orderBy('nama')->get();
        $model = MsModel::orderBy('nama')->get();

        return view('produk.create', compact('pemasok', 'jenisPakaian', 'warna', 'model'));
    }

    // ============================================================
    // STORE — Simpan produk baru + Auto-Generate SKU + Hitung HPP
    // ============================================================
    public function store(Request $request)
    {
        $request->validate([
            'nama_produk'        => 'required|string|max:150',
            'id_jenis_pakaian'   => 'required|exists:ms_jenis_pakaians,id',
            'id_warna'           => 'required|exists:ms_warnas,id',
            'id_model'           => 'required|exists:ms_models,id',
            'harga_jual'         => 'required|numeric|min:0',
            'id_pemasok'         => 'required|exists:pemasok,id',
            'jumlah'             => 'required|integer|min:1',
            'harga_beli_per_unit'=> 'required|numeric|min:0',
            'hpp_realisasi'      => 'nullable|numeric|min:0',
            'foto'               => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'deskripsi'          => 'nullable|string',
        ]);

        DB::beginTransaction();
        try {
            $totalModal  = $request->jumlah * $request->harga_beli_per_unit;
            $hppOtomatis = $totalModal / $request->jumlah;

            $fotoPath = null;
            if ($request->hasFile('foto')) {
                $fotoPath = $request->file('foto')->store('produk', 'public');
            }

            // --- LOGIKA AUTO-GENERATE SKU (JENIS-WARNA-MODEL-###) ---
            $jenis = MsJenisPakaian::findOrFail($request->id_jenis_pakaian);
            $warna = MsWarna::findOrFail($request->id_warna);
            $model = MsModel::findOrFail($request->id_model);

            $prefix = "{$jenis->kode}-{$warna->kode}-{$model->kode}-";

            // Cari urutan terakhir dengan lockForUpdate agar aman saat input bersamaan
            $lastProduk = Produk::where('kode_produk', 'like', $prefix . '%')
                                ->orderBy('kode_produk', 'desc')
                                ->lockForUpdate()
                                ->first();

            if ($lastProduk) {
                $lastNumber = (int) substr($lastProduk->kode_produk, -3);
                $nextNumber = str_pad($lastNumber + 1, 3, '0', STR_PAD_LEFT);
            } else {
                $nextNumber = '001';
            }

            $kodeProduk = $prefix . $nextNumber;
            // --------------------------------------------------------

            $produk = Produk::create([
                'kode_produk'        => $kodeProduk,
                'nama_produk'        => $request->nama_produk,
                'id_jenis_pakaian'   => $request->id_jenis_pakaian,
                'id_warna'           => $request->id_warna,
                'id_model'           => $request->id_model,
                'harga_jual'         => $request->harga_jual,
                'harga_beli_per_unit'=> $request->harga_beli_per_unit,
                'hpp_otomatis'       => $hppOtomatis,
                'hpp_realisasi'      => $request->hpp_realisasi ?? $hppOtomatis,
                'stok'               => $request->jumlah,
                'id_pemasok'         => $request->id_pemasok,
                'foto'               => $fotoPath,
                'deskripsi'          => $request->deskripsi,
                'status'             => 'aktif',
            ]);

            PembelianBarang::create([
                'id_produk'          => $produk->id,
                'qty'                => $request->jumlah,
                'harga_beli_per_unit'=> $request->harga_beli_per_unit,
                'keterangan'         => 'Pembelian awal produk (' . $kodeProduk . ')',
            ]);

            DB::commit();
            return redirect()->route('produk.show', $produk)
                             ->with('success', '⚡ Produk baru [' . $kodeProduk . '] berhasil ditambahkan!');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withInput()->with('error', 'Error: ' . $e->getMessage());
        }
    }

    // ============================================================
    // SHOW — Detail produk
    // ============================================================
    public function show(string $id)
    {
        $produk = Produk::with(['pemasok', 'retur', 'jenisPakaian', 'warna', 'model'])->findOrFail($id);

        $riwayat = PembelianBarang::where('id_produk', $id)
                    ->with('pemasok')
                    ->orderBy('tanggal', 'desc')
                    ->get();

        return view('produk.show', compact('produk', 'riwayat'));
    }

    // ============================================================
    // EDIT — Form edit produk
    // ============================================================
    public function edit(string $id)
    {
        $produk = Produk::findOrFail($id);
        $pemasok = Pemasok::orderBy('nama_pemasok')->get();
        $jenisPakaian = MsJenisPakaian::orderBy('nama')->get();
        $warna = MsWarna::orderBy('nama')->get();
        $model = MsModel::orderBy('nama')->get();
        
        return view('produk.edit', compact('produk', 'pemasok', 'jenisPakaian', 'warna', 'model'));
    }

    // ============================================================
    // UPDATE — Update produk dengan PENAMBAHAN STOK
    // ============================================================
    public function update(Request $request, string $id)
    {
        $produk = Produk::findOrFail($id);

        $request->validate([
            'nama_produk'           => 'required|string|max:150',
            'id_jenis_pakaian'      => 'required|exists:ms_jenis_pakaians,id',
            'id_warna'              => 'required|exists:ms_warnas,id',
            'id_model'              => 'required|exists:ms_models,id',
            'harga_jual'            => 'required|numeric|min:0',
            'id_pemasok'            => 'required|exists:pemasok,id',
            'qty_tambah'            => 'nullable|integer|min:0',
            'harga_beli_per_unit'   => 'nullable|numeric|min:0',
            'hpp_realisasi'         => 'nullable|numeric|min:0',
            'deskripsi'             => 'nullable|string',
        ]);

        DB::beginTransaction();
        try {
            // LOGIC: Jika ada qty_tambah, INCREMENT stok (jangan REPLACE)
            if ($request->filled('qty_tambah') && $request->qty_tambah > 0) {
                $qtyTambah = $request->qty_tambah;
                $hargaBaru = $request->harga_beli_per_unit ?? $produk->harga_beli_per_unit;
                
                // Hitung HPP baru (rata-rata tertimbang dari stok lama + stok baru)
                $nilaiStokLama = $produk->stok * $produk->hpp_otomatis;
                $nilaiStokBaru = $qtyTambah * $hargaBaru;
                $hppBaruOtomatis = ($nilaiStokLama + $nilaiStokBaru) / ($produk->stok + $qtyTambah);
                
                $produk->increment('stok', $qtyTambah);
                
                $produk->update([
                    'nama_produk'        => $request->nama_produk,
                    'id_jenis_pakaian'   => $request->id_jenis_pakaian,
                    'id_warna'           => $request->id_warna,
                    'id_model'           => $request->id_model,
                    'harga_jual'         => $request->harga_jual,
                    'harga_beli_per_unit'=> $hargaBaru,
                    'hpp_otomatis'       => $hppBaruOtomatis,
                    'hpp_realisasi'      => $request->hpp_realisasi ?? $hppBaruOtomatis,
                    'id_pemasok'         => $request->id_pemasok,
                    'deskripsi'          => $request->deskripsi,
                ]);
                
                PembelianBarang::create([
                    'id_produk'          => $produk->id,
                    'qty'                => $qtyTambah,
                    'harga_beli_per_unit'=> $hargaBaru,
                    'keterangan'         => 'Penambahan stok via edit produk',
                ]);
            } else {
                // Update normal tanpa penambahan stok
                $produk->update([
                    'nama_produk'        => $request->nama_produk,
                    'id_jenis_pakaian'   => $request->id_jenis_pakaian,
                    'id_warna'           => $request->id_warna,
                    'id_model'           => $request->id_model,
                    'harga_jual'         => $request->harga_jual,
                    'id_pemasok'         => $request->id_pemasok,
                    'hpp_realisasi'      => $request->hpp_realisasi,
                    'deskripsi'          => $request->deskripsi,
                ]);
            }

            DB::commit();
            return redirect()->route('produk.show', $produk)
                             ->with('success', 'Produk berhasil diperbarui!');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Error: ' . $e->getMessage());
        }
    }

    // ============================================================
    // DELETE — Soft delete produk
    // ============================================================
    public function destroy(string $id)
    {
        $produk = Produk::findOrFail($id);
        $produk->update(['status' => 'nonaktif']);

        return redirect()->route('produk.index')
                         ->with('success', 'Produk berhasil dinonaktifkan!');
    }
}