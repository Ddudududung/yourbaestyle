<?php

namespace App\Http\Controllers;

use App\Models\Produk;
use App\Models\Pemasok;
use App\Models\PembelianBarang;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class ProdukController extends Controller
{
    // ============================================================
    // INDEX — Daftar semua produk
    // ============================================================
    public function index(Request $request)
    {
        $query = Produk::query();

        if ($request->filled('search')) {
            $query->where('nama_produk', 'like', '%' . $request->search . '%')
                  ->orWhere('kode_produk', 'like', '%' . $request->search . '%');
        }

        if ($request->filled('jenis')) {
            $query->where('jenis', $request->jenis);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $produk = $query->orderBy('created_at', 'desc')->paginate(10);

        return view('produk.index', compact('produk'));
    }

    // ============================================================
    // CREATE — Form tambah produk
    // ============================================================
    public function create()
    {
        $pemasok = Pemasok::orderBy('nama_pemasok')->get();
        return view('produk.create', compact('pemasok'));
    }

    // ============================================================
    // STORE — Simpan produk baru + hitung HPP otomatis
    // ============================================================
    public function store(Request $request)
    {
        $request->validate([
            'nama_produk'       => 'required|string|max:150',
            'jenis'             => 'required|in:thrift,rebranding',
            'harga_jual'        => 'required|numeric|min:0',
            'id_pemasok'        => 'required|exists:pemasok,id',
            'jumlah'            => 'required|integer|min:1',
            'harga_beli_per_unit'=> 'required|numeric|min:0',
            'hpp_realisasi'     => 'nullable|numeric|min:0',
            'foto'              => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'deskripsi'         => 'nullable|string',
        ]);

        DB::beginTransaction();
        try {
            // Hitung total modal dan HPP otomatis
            $totalModal  = $request->jumlah * $request->harga_beli_per_unit;
            $hppOtomatis = $totalModal / $request->jumlah;

            // Upload foto jika ada
            $fotoPath = null;
            if ($request->hasFile('foto')) {
                $fotoPath = $request->file('foto')->store('produk', 'public');
            }

            // Generate kode produk otomatis
            $kodeProduk = Produk::generateKode($request->jenis);

            // Simpan produk
            $produk = Produk::create([
                'kode_produk'   => $kodeProduk,
                'nama_produk'   => $request->nama_produk,
                'jenis'         => $request->jenis,
                'deskripsi'     => $request->deskripsi,
                'foto'          => $fotoPath,
                'harga_jual'    => $request->harga_jual,
                'hpp_otomatis'  => $hppOtomatis,
                'hpp_realisasi' => $request->hpp_realisasi,
                'stok'          => $request->jumlah,
                'status'        => 'aktif',
            ]);

            // Catat riwayat pembelian barang
            PembelianBarang::create([
                'id_produk'          => $produk->id,
                'id_pemasok'         => $request->id_pemasok,
                'tanggal'            => now()->toDateString(),
                'jumlah'             => $request->jumlah,
                'harga_beli_per_unit'=> $request->harga_beli_per_unit,
                'total_modal'        => $totalModal,
            ]);

            DB::commit();
            return redirect()->route('produk.index')
                             ->with('success', "Produk {$produk->nama_produk} berhasil ditambahkan.");

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage())
                         ->withInput();
        }
    }

    // ============================================================
    // SHOW — Detail produk
    // ============================================================
    public function show(string $id)
    {
        $produk   = Produk::findOrFail($id);
        $riwayat  = PembelianBarang::where('id_produk', $id)
                                    ->with('pemasok')
                                    ->orderBy('tanggal', 'desc')
                                    ->get();
        return view('produk.show', compact('produk', 'riwayat'));
    }

    // ============================================================
    // EDIT — Form edit produk
    // ============================================================
    public function edit(string $id)
    {
        $produk  = Produk::findOrFail($id);
        $pemasok = Pemasok::orderBy('nama_pemasok')->get();
        return view('produk.edit', compact('produk', 'pemasok'));
    }

    // ============================================================
    // UPDATE — Update data produk (tanpa HPP — HPP diupdate di hppUpdate)
    // ============================================================
    public function update(Request $request, $id)
    {
        $produk = \App\Models\Produk::findOrFail($id);

        // 1. Validasi Input Lengkap (Termasuk foto & stok)
        $request->validate([
            'nama_produk'   => 'required|string|max:255',
            'jenis'         => 'required|in:thrift,rebranding',
            'harga_jual'    => 'required|numeric|min:0',
            'stok'          => 'required|integer|min:0',
            'hpp_otomatis'  => 'nullable|numeric|min:0',
            'hpp_realisasi' => 'nullable|numeric|min:0',
            'status'        => 'required|in:aktif,nonaktif',
            'foto'          => 'nullable|image|mimes:jpeg,png,jpg|max:2048', // Maksimal 2MB
        ], [
            'foto.image' => 'File yang diupload harus berupa gambar.',
            'foto.max'   => 'Ukuran foto maksimal adalah 2MB.',
            'stok.min'   => 'Stok produk tidak boleh minus.'
        ]);

        $data = $request->except(['foto', 'hapus_foto', '_token', '_method']);

        // 2. Logika Hapus Foto Lama jika user mencentang kotak "Hapus Foto Lama"
        if ($request->has('hapus_foto') && $request->hapus_foto == 1) {
            if ($produk->foto && Storage::disk('public')->exists($produk->foto)) {
                Storage::disk('public')->delete($produk->foto);
            }
            $data['foto'] = null;
        }

        // 3. Logika Upload Foto Baru (Jika user memilih file foto baru)
        if ($request->hasFile('foto')) {
            // Hapus foto lama dulu di server agar tidak memenuhi hardisk
            if ($produk->foto && Storage::disk('public')->exists($produk->foto)) {
                Storage::disk('public')->delete($produk->foto);
            }
            // Simpan foto baru ke folder storage/app/public/produk_foto
            $path = $request->file('foto')->store('produk_foto', 'public');
            $data['foto'] = $path;
        }

        // 4. Update data ke database
        $produk->update($data);

        return redirect()->route('produk.index')
            ->with('success', '🌷 Data produk [' . $produk->nama_produk . '] berhasil diperbarui!');
    }

    // ============================================================
    // DESTROY — Hapus produk (soft check: tidak bisa hapus jika ada transaksi)
    // ============================================================
    public function destroy(string $id)
    {
        $produk = Produk::findOrFail($id);

        // Cek apakah produk pernah ada di transaksi
        if ($produk->detailTransaksi()->exists() || $produk->detailPesanan()->exists()) {
            return back()->with('error', 'Produk tidak dapat dihapus karena sudah memiliki riwayat transaksi. Nonaktifkan produk saja.');
        }

        if ($produk->foto) {
            Storage::disk('public')->delete($produk->foto);
        }

        $produk->delete();
        return redirect()->route('produk.index')
                         ->with('success', 'Produk berhasil dihapus.');
    }

    // ============================================================
    // HPP INDEX — Halaman tetapkan HPP Realisasi
    // ============================================================
    public function hppIndex(Request $request)
    {
        // Tampilkan produk yang belum punya HPP realisasi atau ingin diupdate
        $produk = Produk::where('status', 'aktif')
                         ->orderBy('nama_produk')
                         ->paginate(15);

        return view('produk.hpp', compact('produk'));
    }

    // ============================================================
    // HPP UPDATE — Simpan HPP Realisasi
    // ============================================================
    public function hppUpdate(Request $request, string $id)
    {
        $request->validate([
            'hpp_realisasi' => 'nullable|numeric|min:0',
        ]);

        $produk = Produk::findOrFail($id);
        $produk->update(['hpp_realisasi' => $request->hpp_realisasi]);

        $pesan = $request->hpp_realisasi
            ? "HPP Realisasi produk {$produk->nama_produk} berhasil ditetapkan: Rp " . number_format($request->hpp_realisasi, 0, ',', '.')
            : "HPP Realisasi dikosongkan, sistem akan menggunakan HPP Otomatis.";

        return back()->with('success', $pesan);
    }

    // ============================================================
    // API — Ambil data produk untuk POS (JSON)
    // ============================================================
    public function apiProdukAktif()
    {
        $produk = Produk::where('status', 'aktif')
                         ->where('stok', '>', 0)
                         ->get(['id', 'kode_produk', 'nama_produk', 'harga_jual', 'hpp_otomatis', 'hpp_realisasi', 'stok', 'foto']);

        return response()->json($produk->map(function ($p) {
            return [
                'id'          => $p->id,
                'kode'        => $p->kode_produk,
                'nama'        => $p->nama_produk,
                'harga_jual'  => $p->harga_jual,
                'hpp_aktif'   => $p->hpp_aktif, // pakai accessor hpp_realisasi ?? hpp_otomatis
                'stok'        => $p->stok,
                'foto'        => $p->foto ? asset('storage/' . $p->foto) : null,
            ];
        }));
    }
}
