<?php

namespace App\Http\Controllers;

use App\Models\KatalogLive;
use App\Models\Produk;
use Illuminate\Http\Request;

class SesiLiveController extends Controller
{
    /**
     * Menampilkan halaman kerja Co-Host (Form Input + Daftar Mapping Hari Ini)
     */
    public function index(Request $request)
    {
        // Default tanggal adalah hari ini, atau sesuai filter yang dipilih
        $tanggal = $request->input('tanggal', date('Y-m-d'));

        // Ambil daftar kode yang sudah di-mapping oleh Co-Host pada tanggal tersebut
        $mapped = KatalogLive::with('produk')
                    ->whereDate('tanggal_live', $tanggal)
                    ->orderBy('id', 'desc')
                    ->get();

        // Ambil produk aktif yang stoknya masih ada (untuk dropdown)
        $produks = Produk::where('status', 'aktif')
                    ->where('stok', '>', 0)
                    ->orderBy('nama_produk', 'asc')
                    ->get();

        return view('sesi_live.index', compact('mapped', 'produks', 'tanggal'));
    }

    /**
     * Menyimpan mapping baru secara cepat saat Host sedang live
     */
    public function store(Request $request)
    {
        $request->validate([
            'tanggal_live' => 'required|date',
            'kode_live'    => 'required|string|max:50',
            'id_produk'    => 'required|exists:produk,id',
            'harga_live'   => 'nullable|numeric|min:0'
        ], [
            'kode_live.required' => 'Kode live (misal: FIX 10) wajib diisi!',
            'id_produk.required' => 'Silakan pilih produk fisik terlebih dahulu!'
        ]);

        $produk = Produk::findOrFail($request->id_produk);

        // Gunakan harga live jika diisi, jika kosong gunakan harga jual standar produk
        $hargaLive = $request->filled('harga_live') ? $request->harga_live : $produk->harga_jual;

        // Simpan atau update jika kode yang sama sudah ada di hari itu
        KatalogLive::updateOrCreate(
            [
                'kode_live'    => strtoupper(trim($request->kode_live)),
                'tanggal_live' => $request->tanggal_live
            ],
            [
                'id_produk'  => $produk->id,
                'harga_live' => $hargaLive
            ]
        );

        return redirect()->back()->with('success', '⚡ Kode [' . strtoupper($request->kode_live) . '] berhasil dipasangkan dengan ' . $produk->nama_produk . '!');
    }

    /**
     * Menghapus mapping jika Co-Host salah ketik
     */
    public function destroy($id)
    {
        $item = KatalogLive::findOrFail($id);
        $kode = $item->kode_live;
        $item->delete();

        return redirect()->back()->with('success', 'Mapping kode [' . $kode . '] berhasil dihapus.');
    }
}