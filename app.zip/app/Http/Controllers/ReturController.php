<?php

namespace App\Http\Controllers;

use App\Models\Retur;
use App\Models\Produk;
use App\Models\PesananOnline;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ReturController extends Controller
{
    public function index(Request $request)
    {
        $query = Retur::with(['pesananOnline', 'produk', 'user']);

        if ($request->filled('kondisi')) {
            $query->where('kondisi_barang', $request->kondisi);
        }
        if ($request->filled('search')) {
            $query->whereHas('pesananOnline', fn($q) =>
                $q->where('no_pesanan', 'like', '%' . $request->search . '%')
            );
        }

        $retur = $query->orderBy('tanggal', 'desc')->paginate(15);
        return view('retur.index', compact('retur'));
    }

    public function create()
    {
        return view('retur.create');
    }

    // Cari pesanan berdasarkan nomor pesanan (AJAX)
    public function cariPesanan(Request $request)
    {
        $noPesanan = $request->no_pesanan;
        $pesanan   = PesananOnline::with('detail.produk')
                                   ->where('no_pesanan', $noPesanan)
                                   ->first();

        if (!$pesanan) {
            return response()->json(['found' => false, 'message' => 'Nomor pesanan tidak ditemukan.']);
        }

        return response()->json([
            'found'   => true,
            'pesanan' => [
                'id'           => $pesanan->id,
                'no_pesanan'   => $pesanan->no_pesanan,
                'platform'     => $pesanan->platform,
                'nama_pembeli' => $pesanan->nama_pembeli,
                'tanggal'      => $pesanan->tanggal,
                'detail'       => $pesanan->detail->map(fn($d) => [
                    'id_produk'   => $d->id_produk,
                    'nama_produk' => $d->produk->nama_produk,
                    'variasi'     => $d->variasi,
                    'qty'         => $d->qty,
                    'hpp_satuan'  => $d->hpp_satuan,
                ]),
            ],
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_pesanan_online' => 'required|exists:pesanan_online,id',
            'id_produk'         => 'required|exists:produk,id',
            'tanggal'           => 'required|date',
            'alasan'            => 'required|string',
            'kondisi_barang'    => 'required|in:layak_jual,tidak_layak',
            'ongkir_retur'      => 'nullable|numeric|min:0',
        ]);

        DB::beginTransaction();
        try {
            $produk     = Produk::findOrFail($request->id_produk);
            $ongkir     = $request->ongkir_retur ?? 0;

            // Hitung nilai kerugian jika tidak layak jual
            $nilaiKerugian = 0;
            if ($request->kondisi_barang === 'tidak_layak') {
                $nilaiKerugian = $produk->hpp_aktif + $ongkir;
            }

            Retur::create([
                'id_pesanan_online' => $request->id_pesanan_online,
                'id_produk'         => $request->id_produk,
                'id_user'           => Auth::id(),
                'tanggal'           => $request->tanggal,
                'alasan'            => $request->alasan,
                'kondisi_barang'    => $request->kondisi_barang,
                'ongkir_retur'      => $ongkir,
                'nilai_kerugian'    => $nilaiKerugian,
            ]);

            // Jika layak jual, kembalikan stok
            if ($request->kondisi_barang === 'layak_jual') {
                $produk->increment('stok', 1);
            }

            DB::commit();
            return redirect()->route('retur.index')
                             ->with('success', 'Retur berhasil diproses.');

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }

    public function show(string $id)
    {
        $retur = Retur::with(['pesananOnline', 'produk', 'user'])->findOrFail($id);
        return view('retur.show', compact('retur'));
    }
}
