@extends('layouts.app')

@section('title', 'Input Retur Barang ↩')

@section('content')

<div class="card-yb p-4" style="max-width:700px">
    <h6 class="fw-bold mb-4" style="font-family:'Quicksand',sans-serif">Input Retur Barang</h6>

    <p class="text-secondary small fw-bold text-uppercase mb-3">1. Cari Pesanan Asal</p>
    <div class="d-flex gap-2 mb-3">
        <input type="text" id="noPesananInput" class="form-control" placeholder="Masukkan nomor pesanan...">
        <button class="btn btn-yb" onclick="cariPesanan()" id="btnCari">Cari</button>
    </div>

    <div id="hasilPencarian" style="display:none" class="alert alert-success mb-3">
        <strong>✓ Pesanan ditemukan</strong>
        <div id="detailPesanan" class="mt-2 fw-semibold" style="font-size:13px"></div>
    </div>

    <div id="hasilTidakDitemukan" style="display:none" class="alert alert-danger mb-3">
        Nomor pesanan tidak ditemukan. Periksa kembali nomor pesanan.
    </div>

    <form action="{{ route('retur.store') }}" method="POST" id="formRetur" style="display:none">
        @csrf
        <input type="hidden" name="id_pesanan_online" id="id_pesanan_online">
        <input type="hidden" name="id_produk" id="id_produk">

        <p class="text-secondary small fw-bold text-uppercase mb-3 mt-3">2. Detail Retur</p>

        <div class="row g-3 mb-3">
            <div class="col-md-6">
                <label class="form-label">Produk yang Diretur</label>
                <input type="text" id="namaProdukDisplay" class="form-control" readonly style="background:var(--sage-soft)">
            </div>
            <div class="col-md-6">
                <label class="form-label">Tanggal Diterima <span class="text-danger">*</span></label>
                <input type="date" name="tanggal" class="form-control" value="{{ date('Y-m-d') }}" required>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Alasan Retur <span class="text-danger">*</span></label>
            <textarea name="alasan" class="form-control" rows="2" required></textarea>
        </div>

        <label class="form-label">Kondisi Fisik Barang <span class="text-danger">*</span></label>
        <div class="row g-2 mb-3">
            <div class="col-6">
                <input type="radio" name="kondisi_barang" value="layak_jual" id="layak" class="btn-check" checked>
                <label for="layak" class="btn btn-yb-outline w-100 py-2 text-start ps-3">
                    <strong>✅ Layak Jual</strong><br><span style="font-size:11px">Stok bertambah kembali</span>
                </label>
            </div>
            <div class="col-6">
                <input type="radio" name="kondisi_barang" value="tidak_layak" id="tidak_layak" class="btn-check">
                <label for="tidak_layak" class="btn btn-yb-outline w-100 py-2 text-start ps-3">
                    <strong>❌ Tidak Layak</strong><br><span style="font-size:11px">Dicatat sebagai kerugian</span>
                </label>
            </div>
        </div>

        <div class="mb-4">
            <label class="form-label">Ongkos Kirim Retur Ditanggung Toko</label>
            <div class="input-group">
                <span class="input-group-text" style="border-radius:16px 0 0 16px;background:var(--pink-soft);border:2px solid var(--border-soft);border-right:none">Rp</span>
                <input type="number" name="ongkir_retur" class="form-control" value="0" min="0">
            </div>
        </div>

        <div class="d-flex justify-content-end gap-2">
            <a href="{{ route('retur.index') }}" class="btn btn-yb-outline">Batal</a>
            <button type="submit" class="btn btn-yb">Simpan Retur</button>
        </div>
    </form>
</div>

@endsection

@push('scripts')
<script>
function cariPesanan() {
    const noPesanan = document.getElementById('noPesananInput').value.trim();
    if (!noPesanan) return;
    document.getElementById('btnCari').innerHTML = '<span class="spinner-border spinner-border-sm"></span>';

    fetch(`{{ route('retur.cari') }}?no_pesanan=${encodeURIComponent(noPesanan)}`)
        .then(res => res.json())
        .then(data => {
            document.getElementById('btnCari').innerHTML = 'Cari';
            if (data.found) {
                document.getElementById('hasilPencarian').style.display = 'block';
                document.getElementById('hasilTidakDitemukan').style.display = 'none';
                document.getElementById('formRetur').style.display = 'block';
                const p = data.pesanan;
                document.getElementById('detailPesanan').innerHTML = `
                    <div>No. Pesanan: ${p.no_pesanan}</div>
                    <div>Platform: ${p.platform}</div>
                    <div>Pembeli: ${p.nama_pembeli}</div>`;
                document.getElementById('id_pesanan_online').value = p.id;
                if (p.detail.length > 0) {
                    const item = p.detail[0];
                    document.getElementById('id_produk').value = item.id_produk;
                    document.getElementById('namaProdukDisplay').value = item.nama_produk + (item.variasi ? ' - ' + item.variasi : '');
                }
            } else {
                document.getElementById('hasilPencarian').style.display = 'none';
                document.getElementById('hasilTidakDitemukan').style.display = 'block';
                document.getElementById('formRetur').style.display = 'none';
            }
        })
        .catch(() => { document.getElementById('btnCari').innerHTML = 'Cari'; alert('Terjadi kesalahan saat mencari pesanan.'); });
}
document.getElementById('noPesananInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') { e.preventDefault(); cariPesanan(); }
});
</script>
@endpush
