@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')

<div class="container-fluid" style="max-width: 1400px; margin: 0 auto;">

    <!-- ========== STAT CARDS - RESPONSIVE GRID ========== -->
    <div class="row g-3 mb-4">
        
        {{-- Card 1: Transaksi Hari Ini --}}
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="stat-card shadow-sm border-0" style="border-radius: 20px;">
                <div class="stat-icon icon-pink"><i class="bi bi-receipt"></i></div>
                <div class="stat-label">Transaksi Hari Ini</div>
                <div class="stat-value">{{ $transaksiHariIni ?? 0 }}</div>
                <small style="color: var(--ink-soft);"></small>
            </div>
        </div>

        {{-- Card 2: Penjualan Hari Ini --}}
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="stat-card shadow-sm border-0" style="border-radius: 20px;">
                <div class="stat-icon icon-sage"><i class="bi bi-cash-coin"></i></div>
                <div class="stat-label">Penjualan Hari Ini</div>
                <div class="stat-value">Rp {{ number_format($penjualanHariIni ?? 0, 0, ',', '.') }}</div>
                <small style="color: var(--ink-soft);"></small>
            </div>
        </div>

        {{-- Card 3: Total Stok Aktif --}}
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="stat-card shadow-sm border-0" style="border-radius: 20px;">
                <div class="stat-icon icon-amber"><i class="bi bi-box2"></i></div>
                <div class="stat-label">Total Stok Aktif</div>
                <div class="stat-value">{{ $totalStok ?? 0 }}</div>
                <small style="color: var(--ink-soft);"></small>
            </div>
        </div>

        {{-- Card 4: Stok Habis --}}
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="stat-card shadow-sm border-0" style="border-radius: 20px;">
                <div class="stat-icon" style="background: #F0E3F8; color: #8B5F9F;">
                    <i class="bi bi-exclamation-triangle"></i>
                </div>
                <div class="stat-label">Stok Habis</div>
                <div class="stat-value" style="color: #AD5050;">{{ $totalHabis ?? 0 }}</div>
                <small style="color: var(--ink-soft);"></small>
            </div>
        </div>
    </div>

    <!-- ========== RECENT TRANSACTIONS ========== -->
    <div class="card-yb mb-4 shadow-sm border-0" style="border-radius: 24px; overflow: hidden; background: #fff;">
        <div class="card-header bg-white" style="padding: 20px 24px; border-bottom: 1px solid #F7E5EA;">
            <div class="d-flex justify-content-between align-items-center">
                <h6 style="margin: 0; font-weight: 700; color: #4D3D43; font-family: 'Quicksand', sans-serif;">
                    <i class="bi bi-receipt me-2" style="color: #EC95A8;"></i>Transaksi Terakhir
                </h6>
                <a href="{{ route('transaksi.index') }}" class="btn btn-yb rounded-pill" style="padding: 6px 16px; font-size: 12px; font-weight: 600;">
                    Lihat Semua <i class="bi bi-arrow-right ms-1"></i>
                </a>
            </div>
        </div>
        <div class="card-body p-0">
            {{-- Desktop & Tablet View --}}
            <div class="d-none d-md-block">
                <div class="table-responsive" style="border-radius: 0;">
                    <table class="table table-hover align-middle mb-0" style="font-size: 13.5px;">
                        <thead style="background-color: #FFF5F7; color: #7A686D; font-size: 11.5px; letter-spacing: 0.5px; text-transform: uppercase;">
                            <tr>
                                <th class="py-3 ps-4 border-0">No. Transaksi</th>
                                <th class="py-3 border-0">Produk</th>
                                <th class="py-3 text-center border-0">Qty</th>
                                <th class="py-3 text-end border-0">Total</th>
                                <th class="py-3 text-end border-0">Waktu</th>
                                <th class="py-3 pe-4 text-end border-0">User</th>
                            </tr>
                        </thead>
                        <tbody style="border-top: 1px solid #F7E5EA;">
                            @forelse($recentTransactions ?? [] as $tx)
                            <tr>
                                <td class="ps-4"><code style="font-size: 11.5px; color: #EC95A8; font-weight: 700; background: #FFF0F3; padding: 4px 8px; border-radius: 6px;">{{ $tx->no_transaksi ?? '-' }}</code></td>
                                <td class="fw-semibold text-dark">{{ substr($tx->produk_nama ?? '-', 0, 30) }}</td>
                                <td class="text-center fw-bold">{{ $tx->qty ?? 0 }}</td>
                                <td class="text-end fw-bold" style="color: #4D3D43;">Rp {{ number_format($tx->total ?? 0, 0, ',', '.') }}</td>
                                <td class="text-end text-muted"><small>{{ $tx->created_at?->diffForHumans() ?? '-' }}</small></td>
                                <td class="pe-4 text-end"><span class="badge bg-light text-secondary border px-2 py-1">{{ $tx->user_name ?? '-' }}</span></td>
                            </tr>
                            @empty
                            <!-- EMPTY STATE DESKTOP YANG ELEGAN -->
                            <tr>
                                <td colspan="6" class="text-center py-5">
                                    <div class="py-4">
                                        <div class="mb-3" style="font-size: 3rem; color: #F6C9D3;">
                                            <i class="bi bi-inbox"></i>
                                        </div>
                                        <h6 class="fw-bold mb-1" style="color: #4D3D43;">Belum ada transaksi yang tercatat</h6>
                                        <p class="text-muted small mb-0">Transaksi baru akan muncul secara otomatis di sini.</p>
                                    </div>
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>

            {{-- Mobile View (List Format) --}}
            <div class="d-md-none" style="padding: 8px 16px;">
                @forelse($recentTransactions ?? [] as $tx)
                <div style="padding: 14px 0; border-bottom: 1px solid #F7E5EA;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 8px;">
                        <div style="flex: 1;">
                            <div style="margin-bottom: 6px;">
                                <code style="font-size: 11px; color: #EC95A8; font-weight: 700; background: #FFF0F3; padding: 3px 6px; border-radius: 4px;">{{ $tx->no_transaksi ?? '-' }}</code>
                            </div>
                            <div style="font-weight: 700; color: #4D3D43; margin-bottom: 4px; font-size: 13.5px;">{{ substr($tx->produk_nama ?? '-', 0, 25) }}</div>
                            <div style="font-size: 11.5px; color: #8C7B80;">
                                <i class="bi bi-box me-1"></i>{{ $tx->qty ?? 0 }} pcs • <i class="bi bi-clock ms-1 me-1"></i>{{ $tx->created_at?->diffForHumans() ?? '-' }}
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-weight: 700; color: #EC95A8; font-size: 14px;">
                                Rp {{ number_format($tx->total ?? 0, 0, ',', '.') }}
                            </div>
                            <div style="margin-top: 6px;">
                                <span class="badge bg-light text-secondary border" style="font-size: 10px;">{{ $tx->user_name ?? '-' }}</span>
                            </div>
                        </div>
                    </div>
                </div>
                @empty
                <!-- EMPTY STATE MOBILE YANG ELEGAN -->
                <div class="text-center py-5">
                    <div class="mb-2" style="font-size: 2.5rem; color: #F6C9D3;">
                        <i class="bi bi-inbox"></i>
                    </div>
                    <h6 class="fw-bold mb-1" style="color: #4D3D43; font-size: 14px;">Belum ada transaksi</h6>
                    <p class="text-muted small mb-0" style="font-size: 12px;">Data transaksi masih kosong.</p>
                </div>
                @endforelse
            </div>
        </div>
    </div>

    <!-- ========== LOW STOCK PRODUCTS ========== -->
    <div class="row g-3">
        <div class="col-12">
            <div class="card-yb shadow-sm border-0" style="border-radius: 24px; overflow: hidden; background: #fff;">
                <div class="card-header bg-white" style="padding: 20px 24px; border-bottom: 1px solid #F7E5EA;">
                    <div class="d-flex justify-content-between align-items-center">
                        <h6 style="margin: 0; font-weight: 700; color: #4D3D43; font-family: 'Quicksand', sans-serif;">
                            <i class="bi bi-exclamation-triangle-fill me-2 text-warning"></i>Produk Stok Rendah
                        </h6>
                        <a href="{{ route('produk.index', ['status' => 'aktif']) }}" class="btn btn-yb-outline rounded-pill" style="padding: 6px 16px; font-size: 12px; font-weight: 600;">
                            Kelola Stok <i class="bi bi-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
                <div class="card-body p-0">
                    {{-- Desktop & Tablet View --}}
                    <div class="d-none d-md-block">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0" style="font-size: 13.5px;">
                                <thead style="background-color: #FFF5F7; color: #7A686D; font-size: 11.5px; letter-spacing: 0.5px; text-transform: uppercase;">
                                    <tr>
                                        <th class="py-3 ps-4 border-0">Produk</th>
                                        <th class="py-3 text-center border-0">Stok Saat Ini</th>
                                        <th class="py-3 text-center border-0">Stok Minimum</th>
                                        <th class="py-3 text-center border-0">Status</th>
                                        <th class="py-3 pe-4 text-end border-0">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody style="border-top: 1px solid #F7E5EA;">
                                    {{-- MENGGUNAKAN VARIABEL $lowStockProducts DARI CONTROLLER --}}
                                    @forelse($lowStockProducts ?? [] as $prod)
                                    <tr>
                                        <td class="ps-4 fw-bold text-dark">{{ $prod->nama_produk ?? '-' }}</td>
                                        <td class="text-center">
                                            <span style="color: #AD5050; font-weight: 800; font-size: 15px; background: #FCEAEA; padding: 4px 10px; border-radius: 8px;">{{ $prod->stok ?? 0 }}</span>
                                        </td>
                                        <td class="text-center text-muted fw-semibold">{{ $prod->stok_minimum ?? 5 }}</td>
                                        <td class="text-center">
                                            @if($prod->stok == 0)
                                                <span class="badge bg-danger px-3 py-1 rounded-pill">Habis</span>
                                            @elseif($prod->stok <= ($prod->stok_minimum ?? 5))
                                                <span class="badge bg-warning text-dark px-3 py-1 rounded-pill">Rendah</span>
                                            @endif
                                        </td>
                                        <td class="pe-4 text-end">
                                            <a href="{{ route('produk.edit', $prod->id) }}" class="btn btn-sm btn-yb rounded-pill px-3" style="font-size: 11px; font-weight: 600;">
                                                <i class="bi bi-pencil-square me-1"></i> Edit
                                            </a>
                                        </td>
                                    </tr>
                                    @empty
                                    <!-- EMPTY STATE DESKTOP YANG LENGKAP & CENTERED -->
                                    <tr>
                                        <td colspan="5" class="text-center py-5">
                                            <div class="py-4">
                                                <div class="mb-3" style="font-size: 3rem; color: #C7DBC1;">
                                                    <i class="bi bi-check-circle-fill"></i>
                                                </div>
                                                <h6 class="fw-bold mb-1" style="color: #4D3D43;">Semua stok terpenuhi dengan baik! ✓</h6>
                                                <p class="text-muted small mb-0">Tidak ada produk yang berada di bawah batas minimum stok saat ini.</p>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>

                    {{-- Mobile View (Card Format) --}}
                    <div class="d-md-none" style="padding: 8px 16px;">
                        @forelse($lowStockProducts ?? [] as $prod)
                        <div style="padding: 14px 0; border-bottom: 1px solid #F7E5EA;">
                            <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px;">
                                <div style="flex: 1;">
                                    <div style="font-weight: 700; color: #4D3D43; margin-bottom: 6px; font-size: 13.5px;">{{ $prod->nama_produk ?? '-' }}</div>
                                    <div style="font-size: 12px; color: #8C7B80;">
                                        Stok: <strong style="color: #AD5050; background: #FCEAEA; padding: 2px 6px; border-radius: 4px;">{{ $prod->stok ?? 0 }}</strong> / {{ $prod->stok_minimum ?? 5 }}
                                    </div>
                                </div>
                                <div style="text-align: right;">
                                    @if($prod->stok == 0)
                                        <span class="badge bg-danger rounded-pill px-2 py-1 d-block mb-2">Habis</span>
                                    @elseif($prod->stok <= ($prod->stok_minimum ?? 5))
                                        <span class="badge bg-warning text-dark rounded-pill px-2 py-1 d-block mb-2">Rendah</span>
                                    @endif
                                    <div>
                                        <a href="{{ route('produk.edit', $prod->id) }}" class="btn btn-sm btn-yb rounded-pill px-3" style="font-size: 11px; font-weight: 600; white-space: nowrap;">
                                            Edit
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @empty
                        <!-- EMPTY STATE MOBILE YANG LENGKAP -->
                        <div class="text-center py-5">
                            <div class="mb-2" style="font-size: 2.5rem; color: #C7DBC1;">
                                <i class="bi bi-check-circle-fill"></i>
                            </div>
                            <h6 class="fw-bold mb-1" style="color: #4D3D43; font-size: 14px;">Stok Terpenuhi ✓</h6>
                            <p class="text-muted small mb-0" style="font-size: 12px;">Semua produk dalam kondisi aman (stok cukup).</p>
                        </div>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<style>
    /* Dashboard responsive adjustments */
    @media (max-width: 768px) {
        .stat-value {
            font-size: 20px !important;
        }

        .stat-label {
            font-size: 11px !important;
        }

        .card-header {
            padding: 16px !important;
        }

        .badge {
            font-size: 10px !important;
            padding: 3px 8px !important;
        }
    }

    @media (max-width: 480px) {
        .stat-value {
            font-size: 18px !important;
        }

        .card-header h6 {
            font-size: 14px;
        }

        .btn {
            font-size: 11px !important;
            padding: 6px 12px !important;
        }
    }
</style>

@endsection