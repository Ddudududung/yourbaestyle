@extends('layouts.app')

@section('title', 'Manajemen Barang')

@section('content')

<!-- ==================================================== -->
<!-- 1. FILTER PENCARIAN & TOMBOL TAMBAH (RESPONSIVE GRID) -->
<!-- ==================================================== -->
<div class="card border-0 shadow-sm rounded-4 mb-4" style="background: #fff;">
    <div class="card-body p-3 p-md-4">
        <form method="GET" class="row g-2 align-items-center">
            <div class="col-12 col-lg-4">
                <input type="text" name="search" class="form-control" placeholder="Cari nama atau kode produk..." value="{{ request('search') }}">
            </div>
            <div class="col-6 col-lg-2">
                <select name="jenis" class="form-select">
                    <option value="">Semua Jenis</option>
                    <option value="thrift" {{ request('jenis')=='thrift'?'selected':'' }}>Thrift</option>
                    <option value="rebranding" {{ request('jenis')=='rebranding'?'selected':'' }}>Rebranding</option>
                </select>
            </div>
            <div class="col-6 col-lg-2">
                <select name="status" class="form-select">
                    <option value="">Semua Status</option>
                    <option value="aktif" {{ request('status')=='aktif'?'selected':'' }}>Aktif</option>
                    <option value="nonaktif" {{ request('status')=='nonaktif'?'selected':'' }}>Nonaktif</option>
                </select>
            </div>
            <div class="col-12 col-lg-4 d-flex gap-2 mt-2 mt-lg-0">
                <button type="submit" class="btn btn-yb-outline shrink-0" title="Cari"><i class="bi bi-search"></i></button>
                <a href="{{ route('produk.create') }}" class="btn btn-yb w-100 fw-bold"><i class="bi bi-plus-lg me-1"></i> Tambah Produk</a>
            </div>
        </form>
    </div>
</div>

<!-- ==================================================== -->
<!-- 2. KOTA UTAMA DATA PRODUK                            -->
<!-- ==================================================== -->
<div class="card-yb border-0 shadow-sm rounded-4 mb-4" style="background: #fff; overflow: hidden;">
    
    <!-- A. TAMPILAN LAPTOP / DESKTOP (TABEL 10 KOLOM) -->
    <div class="d-none d-lg-block">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 text-nowrap" style="font-size: 13.5px;">
                <thead style="background-color: #FFF5F7; color: #7A686D; font-size: 11.5px; letter-spacing: 0.5px; text-transform: uppercase;">
                    <tr>
                        <th class="py-3 ps-4 border-0">Foto</th>
                        <th class="py-3 border-0">Kode</th>
                        <th class="py-3 border-0">Nama Produk</th>
                        <th class="py-3 border-0">Jenis</th>
                        <th class="py-3 text-end border-0">Harga Jual</th>
                        <th class="py-3 text-end border-0">HPP Otomatis</th>
                        <th class="py-3 text-end border-0">HPP Realisasi</th>
                        <th class="py-3 text-center border-0">Stok</th>
                        <th class="py-3 text-center border-0">Status</th>
                        <th class="py-3 pe-4 text-end border-0">Aksi</th>
                    </tr>
                </thead>
                <tbody style="border-top: 1px solid #F7E5EA;">
                    @forelse($produk as $p)
                    <tr>
                        <td class="ps-4">
                            @if($p->foto)
                                <img src="{{ asset('storage/'.$p->foto) }}" width="42" height="42" style="object-fit:cover; border-radius:12px; border: 1px solid #F7E5EA;">
                            @else
                                <div style="width:42px; height:42px; background:var(--pink-soft, #FFF0F3); border-radius:12px; display:flex; align-items:center; justify-content:center;">
                                    <i class="bi bi-bag-heart" style="color:var(--pink-primary-dark, #EC95A8);"></i>
                                </div>
                            @endif
                        </td>
                        <td><code style="background: #FFF0F3; color: #EC95A8; padding: 4px 8px; border-radius: 6px; font-weight: 700; font-size: 12px;">{{ $p->kode_produk }}</code></td>
                        <td class="fw-bold text-dark">{{ $p->nama_produk }}</td>
                        <td><span class="badge bg-light text-secondary border px-3 py-1 rounded-pill">{{ ucfirst($p->jenis) }}</span></td>
                        <td class="text-end fw-bold" style="color: #4D3D43;">Rp {{ number_format($p->harga_jual, 0, ',', '.') }}</td>
                        <td class="text-end text-muted">Rp {{ number_format($p->hpp_otomatis, 0, ',', '.') }}</td>
                        <td class="text-end">
                            @if($p->hpp_realisasi)
                                <span class="fw-semibold text-dark">Rp {{ number_format($p->hpp_realisasi, 0, ',', '.') }}</span>
                            @else
                                <span class="text-secondary">—</span>
                            @endif
                        </td>
                        <td class="text-center">
                            <span class="badge {{ $p->stok <= 3 ? 'bg-danger' : 'bg-light text-dark border' }} px-3 py-1 rounded-pill fw-bold">{{ $p->stok }} pcs</span>
                        </td>
                        <td class="text-center">
                            <span class="badge {{ $p->status=='aktif' ? 'bg-success-subtle text-success border border-success-subtle' : 'bg-secondary-subtle text-secondary border border-secondary-subtle' }} px-3 py-1 rounded-pill">
                                {{ ucfirst($p->status) }}
                            </span>
                        </td>
                        <td class="pe-4 text-end">
                            <div class="d-flex justify-content-end gap-1">
                                <a href="{{ route('produk.show', $p->id) }}" class="btn btn-sm btn-outline-secondary rounded-pill" title="Lihat"><i class="bi bi-eye"></i></a>
                                <a href="{{ route('produk.edit', $p->id) }}" class="btn btn-sm btn-outline-primary rounded-pill" title="Edit"><i class="bi bi-pencil"></i></a>
                                <form action="{{ route('produk.destroy', $p->id) }}" method="POST" onsubmit="return confirm('Hapus produk ini?')">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill" title="Hapus"><i class="bi bi-trash"></i></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="10" class="text-center text-secondary py-5">Belum ada data produk 🌷</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <!-- B. TAMPILAN HP / MOBILE (FORMAT KARTU / CARD LIST) -->
    <div class="d-lg-none p-3" style="background: #FAF8F9;">
        @forelse($produk as $p)
        <div class="card border-0 shadow-sm rounded-4 mb-3 p-3" style="background: #fff; border: 1px solid #F7E5EA !important;">
            
            <!-- Baris 1: Foto, Kode, Jenis & Status -->
            <div class="d-flex align-items-center justify-content-between mb-3 pb-2 border-bottom" style="border-color: #F7E5EA !important;">
                <div class="d-flex align-items-center gap-2">
                    @if($p->foto)
                        <img src="{{ asset('storage/'.$p->foto) }}" width="45" height="45" style="object-fit:cover; border-radius:10px; border: 1px solid #F7E5EA;">
                    @else
                        <div style="width:45px; height:45px; background:var(--pink-soft, #FFF0F3); border-radius:10px; display:flex; align-items:center; justify-content:center;">
                            <i class="bi bi-bag-heart fs-5" style="color:var(--pink-primary-dark, #EC95A8);"></i>
                        </div>
                    @endif
                    <div>
                        <code style="background: #FFF0F3; color: #EC95A8; padding: 3px 6px; border-radius: 4px; font-weight: 700; font-size: 11px;">{{ $p->kode_produk }}</code>
                        <div class="mt-1">
                            <span class="badge bg-light text-secondary border" style="font-size: 10px;">{{ ucfirst($p->jenis) }}</span>
                        </div>
                    </div>
                </div>
                <div class="text-end">
                    <span class="badge {{ $p->status=='aktif' ? 'bg-success' : 'bg-secondary' }} rounded-pill" style="font-size: 10px;">
                        {{ ucfirst($p->status) }}
                    </span>
                    <div class="mt-1">
                        <span class="badge {{ $p->stok <= 3 ? 'bg-danger' : 'bg-light text-dark border' }}" style="font-size: 11px;">
                            Stok: {{ $p->stok }}
                        </span>
                    </div>
                </div>
            </div>

            <!-- Baris 2: Nama Produk -->
            <h6 class="fw-bold mb-3 text-dark" style="font-size: 15px; line-height: 1.4;">{{ $p->nama_produk }}</h6>

            <!-- Baris 3: Kotak Harga (Grid 3 Kolom) -->
            <div class="row g-2 mb-3 p-2 rounded-3 text-center" style="background: #FFF5F7; font-size: 11.5px;">
                <div class="col-4 border-end" style="border-color: #FCEAEA !important;">
                    <span class="text-muted d-block" style="font-size: 10px;">Harga Jual</span>
                    <strong style="color: #4D3D43;">Rp {{ number_format($p->harga_jual, 0, ',', '.') }}</strong>
                </div>
                <div class="col-4 border-end" style="border-color: #FCEAEA !important;">
                    <span class="text-muted d-block" style="font-size: 10px;">HPP Otomatis</span>
                    <strong style="color: #7A686D;">Rp {{ number_format($p->hpp_otomatis, 0, ',', '.') }}</strong>
                </div>
                <div class="col-4">
                    <span class="text-muted d-block" style="font-size: 10px;">HPP Real</span>
                    <strong style="color: #7A686D;">
                        {{ $p->hpp_realisasi ? 'Rp '.number_format($p->hpp_realisasi, 0, ',', '.') : '—' }}
                    </strong>
                </div>
            </div>

            <!-- Baris 4: Tombol Aksi -->
            <div class="d-flex justify-content-between align-items-center pt-1">
                <a href="{{ route('produk.show', $p->id) }}" class="btn btn-sm btn-outline-secondary rounded-pill px-3" style="font-size: 12px;">
                    <i class="bi bi-eye me-1"></i> Detail
                </a>
                <div class="d-flex gap-2">
                    <a href="{{ route('produk.edit', $p->id) }}" class="btn btn-sm rounded-pill px-3 fw-bold" style="background: #EC95A8; color: #fff; font-size: 12px;">
                        <i class="bi bi-pencil me-1"></i> Edit
                    </a>
                    <form action="{{ route('produk.destroy', $p->id) }}" method="POST" onsubmit="return confirm('Hapus produk ini?')">
                        @csrf @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill px-2" title="Hapus"><i class="bi bi-trash"></i></button>
                    </form>
                </div>
            </div>

        </div>
        @empty
        <div class="text-center py-5">
            <i class="bi bi-inbox fs-1 text-muted d-block mb-2"></i>
            <p class="text-muted mb-0 small">Belum ada data produk 🌷</p>
        </div>
        @endforelse
    </div>

    <!-- C. PAGINATION / LINKS -->
    @if($produk->hasPages())
    <div class="card-footer bg-white py-3 px-4 border-top" style="border-color: #F7E5EA !important;">
        {{ $produk->links() }}
    </div>
    @endif

</div>

@endsection