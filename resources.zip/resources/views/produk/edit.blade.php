@extends('layouts.app')

@section('title', 'Edit Produk — Yourbaestyle')

@section('content')
<div class="container-fluid py-4" style="max-width: 900px; margin: 0 auto;">
    
    <!-- Tombol Kembali -->
    <div class="mb-3">
        <a href="{{ route('produk.index') }}" class="btn btn-sm btn-outline-secondary rounded-pill px-3 fw-bold">
            <i class="bi bi-arrow-left me-1"></i> Kembali ke Daftar
        </a>
    </div>

    <!-- Kartu Form Edit -->
    <div class="card border-0 shadow-sm rounded-4" style="background: #fff; overflow: hidden;">
        <div class="card-header bg-white py-3 px-4 border-bottom" style="border-color: #F7E5EA !important;">
            <h5 class="mb-0 fw-bold" style="color: #4D3D43; font-family: 'Quicksand', sans-serif;">
                <i class="bi bi-pencil-square me-2" style="color: #EC95A8;"></i>Edit Data Produk
            </h5>
        </div>

        <div class="card-body p-4">
            
            <!-- PESAN ERROR VALIDASI -->
            @if ($errors->any())
                <div class="alert alert-danger rounded-3 mb-4 text-sm">
                    <ul class="mb-0 ps-3">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <!-- PASTIKAN ADA enctype="multipart/form-data" AGAR BISA UPLOAD FOTO -->
            <form action="{{ route('produk.update', $produk->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <!-- ==================== BAGIAN 1: FOTO PRODUK ==================== -->
                <div class="mb-4 p-3 rounded-4" style="background: #FFF5F7; border: 1px dashed #EC95A8;">
                    <label class="form-label fw-bold" style="color: #4D3D43;">Foto Produk</label>
                    <div class="d-flex align-items-center gap-3 flex-wrap">
                        
                        <!-- Preview Foto Saat Ini -->
                        <div class="text-center">
                            @if($produk->foto && file_exists(storage_path('app/public/' . $produk->foto)))
                                <img src="{{ asset('storage/' . $produk->foto) }}" width="100" height="100" class="rounded-3 shadow-sm mb-1" style="object-fit: cover; border: 2px solid #fff;">
                                <div class="form-check form-check-inline mt-1 d-block">
                                    <input class="form-check-input" type="checkbox" name="hapus_foto" value="1" id="hapusFoto">
                                    <label class="form-check-label text-danger small fw-bold" for="hapusFoto">Hapus Foto Lama</label>
                                </div>
                            @else
                                <div style="width: 100px; height: 100px; background: #fff; border-radius: 12px; display: flex; align-items: center; justify-content: center; border: 1px solid #F7E5EA;">
                                    <i class="bi bi-camera fs-1 text-muted"></i>
                                </div>
                                <span class="d-block small text-muted mt-1">Belum ada foto</span>
                            @endif
                        </div>

                        <!-- Input Upload Baru -->
                        <div class="grow">
                            <input type="file" name="foto" class="form-control form-control-sm" accept="image/png, image/jpeg, image/jpg">
                            <small class="text-muted d-block mt-1" style="font-size: 11.5px;">
                                <i class="bi bi-info-circle me-1"></i>Format yang diizinkan: JPG, JPEG, PNG (Maks. 2MB). Biarkan kosong jika tidak ingin mengganti foto.
                            </small>
                        </div>
                    </div>
                </div>

                <!-- ==================== BAGIAN 2: INFORMASI UTAMA ==================== -->
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-dark">Kode Produk</label>
                        <input type="text" class="form-control bg-light" value="{{ $produk->kode_produk }}" readonly>
                        <small class="text-muted" style="font-size: 11px;">Kode produk otomatis dikunci oleh sistem agar riwayat aman.</small>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold text-dark">Status Produk <span class="text-danger">*</span></label>
                        <select name="status" class="form-select" required>
                            <option value="aktif" {{ old('status', $produk->status) == 'aktif' ? 'selected' : '' }}>Aktif / Dijual</option>
                            <option value="nonaktif" {{ old('status', $produk->status) == 'nonaktif' ? 'selected' : '' }}>Nonaktif / Arsip</option>
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-bold text-dark">Nama Produk <span class="text-danger">*</span></label>
                        <input type="text" name="nama_produk" class="form-control" value="{{ old('nama_produk', $produk->nama_produk) }}" required placeholder="Contoh: Knitwear Kuning Garis">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold text-dark">Jenis Barang <span class="text-danger">*</span></label>
                        <select name="jenis" class="form-select" required>
                            <option value="thrift" {{ old('jenis', $produk->jenis) == 'thrift' ? 'selected' : '' }}>Thrift</option>
                            <option value="rebranding" {{ old('jenis', $produk->jenis) == 'rebranding' ? 'selected' : '' }}>Rebranding</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold text-dark">Harga Jual (Rp) <span class="text-danger">*</span></label>
                        <input type="number" name="harga_jual" class="form-control" value="{{ old('harga_jual', $produk->harga_jual) }}" required min="0" step="500">
                    </div>
                </div>

                <!-- ==================== BAGIAN 3: STOK & HPP (DIBUKA KUNCINYA) ==================== -->
                <div class="p-3 mb-3 rounded-4" style="background: #FAF8F9; border: 1px solid #F7E5EA;">
                    <h6 class="fw-bold mb-3" style="color: #4D3D43; font-size: 13.5px;">
                        <i class="bi bi-box-seam me-1" style="color: #EC95A8;"></i>Koreksi Stok & Modal (HPP)
                    </h6>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label fw-bold text-dark">Stok Fisik <span class="text-danger">*</span></label>
                            <input type="number" name="stok" class="form-control border-danger-subtle" value="{{ old('stok', $produk->stok) }}" required min="0">
                            <small class="text-muted" style="font-size: 11px;">Stok saat ini di gudang.</small>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold text-dark">HPP Otomatis (Rp)</label>
                            <input type="number" name="hpp_otomatis" class="form-control" value="{{ old('hpp_otomatis', $produk->hpp_otomatis) }}" min="0" step="500">
                            <small class="text-muted" style="font-size: 11px;">Modal sistem (otomatis/input).</small>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold text-dark">HPP Realisasi (Rp)</label>
                            <input type="number" name="hpp_realisasi" class="form-control" value="{{ old('hpp_realisasi', $produk->hpp_realisasi) }}" min="0" step="500" placeholder="Opsional">
                            <small class="text-muted" style="font-size: 11px;">Modal asli belanja aktual.</small>
                        </div>
                    </div>
                </div>

                <!-- ==================== BAGIAN 4: DESKRIPSI ==================== -->
                <div class="mb-4">
                    <label class="form-label fw-bold text-dark">Deskripsi Produk</label>
                    <textarea name="deskripsi" class="form-control" rows="3" placeholder="Tuliskan ukuran, minus barang thrift, atau bahan kain...">{{ old('deskripsi', $produk->deskripsi) }}</textarea>
                </div>

                <!-- TOMBOL SIMPAN -->
                <div class="d-flex justify-content-end gap-2 pt-3 border-top" style="border-color: #F7E5EA !important;">
                    <a href="{{ route('produk.index') }}" class="btn btn-light rounded-pill px-4 fw-semibold border">Batal</a>
                    <button type="submit" class="btn rounded-pill px-4 fw-bold text-white shadow-sm" style="background: #EC95A8;">
                        <i class="bi bi-check2-circle me-1"></i> Simpan Perubahan
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>
@endsection